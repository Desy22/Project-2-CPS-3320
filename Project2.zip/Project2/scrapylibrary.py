import scrapy

class QuotesSpider(scrapy.Spider):
    name = "quotes"
    start_urls = [
        'https://scrapy.org',
        'https://docs.scrapy.org/en/latest/intro/tutorial.html',
    ]

    def parse(self, response):
        titles = response.css('.title.may-blank::text').extract()

##Must do 'scrapy crawl quotes' in terminal in files directory