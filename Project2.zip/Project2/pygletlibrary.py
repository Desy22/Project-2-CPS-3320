import pyglet 

window = pyglet.window.Window()

animation = pyglet.image.load_animation('giphy.gif')
bin = pyglet.image.atlas.TextureBin()
animation.add_to_texture_bin(bin)
sprite = pyglet.sprite.Sprite(img=animation)

label = pyglet.text.Label('Introduction to Pyglet',
						font_name='Roboto',
						font_size=40,
						x=window.width//2, y=window.height//2,
						anchor_x='center', anchor_y='center')

@window.event
def on_draw():
	window.clear()
	sprite.draw()
	label.draw()

pyglet.app.run()