import pygame
import time
import random
 
Sspeed = 10

window_x = 920
window_y = 680

white = pygame.Color(255, 255, 255)
red = pygame.Color(255, 0, 0)
green = pygame.Color(34,139,34)
bgblue = pygame.Color(173,216,230)
 
pygame.init()
 
pygame.display.set_caption('Destiny\'s Snake Game')
game_window = pygame.display.set_mode((window_x, window_y))

fps = pygame.time.Clock()

snakepos = [100, 50]

snakeBody = [[100, 50],
              [90, 50],
              [80, 50],
              [70, 50]
              ]

fruitpos = [random.randrange(1, (window_x//10)) * 10,
                  random.randrange(1, (window_y//10)) * 10]
 
fruit_spawn = True
 
direction = 'RIGHT'
change_to = direction
 
score = 0
 
def display_score(choice, color, font, size):

    scoreFont = pygame.font.SysFont(font, size)
     
    Ssurface = scoreFont.render('Score : ' + str(score), True, color)

    score_rect = Ssurface.get_rect()

    game_window.blit(Ssurface, score_rect)

def game_over():
   
    fontstyle = pygame.font.SysFont('Roboto', 120)
     
    game_overS = fontstyle.render(
        'Your Score is : ' + str(score), True, white)

    game_over_rect = game_overS.get_rect()

    game_over_rect.midtop = (window_x/2, window_y/4)

    game_window.blit(game_overS, game_over_rect)
    pygame.display.flip()

    time.sleep(2)

    pygame.quit()

    quit()

while True:

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                change_to = 'UP'
            if event.key == pygame.K_DOWN:
                change_to = 'DOWN'
            if event.key == pygame.K_LEFT:
                change_to = 'LEFT'
            if event.key == pygame.K_RIGHT:
                change_to = 'RIGHT'

    if change_to == 'UP' and direction != 'DOWN':
        direction = 'UP'
    if change_to == 'DOWN' and direction != 'UP':
        direction = 'DOWN'
    if change_to == 'LEFT' and direction != 'RIGHT':
        direction = 'LEFT'
    if change_to == 'RIGHT' and direction != 'LEFT':
        direction = 'RIGHT'

    if direction == 'UP':
        snakepos[1] -= 10
    if direction == 'DOWN':
        snakepos[1] += 10
    if direction == 'LEFT':
        snakepos[0] -= 10
    if direction == 'RIGHT':
        snakepos[0] += 10

    snakeBody.insert(0, list(snakepos))
    if snakepos[0] == fruitpos[0] and snakepos[1] == fruitpos[1]:
        score += 1
        fruit_spawn = False
    else:
        snakeBody.pop()
         
    if not fruit_spawn:
        fruitpos = [random.randrange(1, (window_x//10)) * 10,
                          random.randrange(1, (window_y//10)) * 10]
         
    fruit_spawn = True
    game_window.fill(bgblue)
     
    for pos in snakeBody:
        pygame.draw.rect(game_window, green,
                         pygame.Rect(pos[0], pos[1], 15, 15))
    pygame.draw.rect(game_window, red, pygame.Rect(
        fruitpos[0], fruitpos[1], 15, 15))
 
    if snakepos[0] < 0 or snakepos[0] > window_x-10:
        game_over()
    if snakepos[1] < 0 or snakepos[1] > window_y-10:
        game_over()
 
    for block in snakeBody[1:]:
        if snakepos[0] == block[0] and snakepos[1] == block[1]:
            game_over()

    display_score(1, white, 'Roboto', 40)

    pygame.display.update()
 
    fps.tick(Sspeed)